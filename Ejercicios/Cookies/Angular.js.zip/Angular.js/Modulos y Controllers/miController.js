var app = angular.module("elModulo", []);

app.controller("elController", function($scope) {
    $scope.Saludo1 = "Hola jóvenes,";
    $scope.Saludo2 = "Como están!!!";
});

